
<div class="footer">
	<div class="copyright">
		Copyright 2012 ~
		<script>document.write(new Date().getFullYear());</script>
		<a href="http://tiankonguse.com">tiankonguse.com</a>. All rights
		reserved.
	</div>
	<div class="copyright">email : i@tiankonguse.com</div>
	<div class="copyright">QQ : 804345178</div>
	<div class="copyright">如果本站侵犯你的bulabula,请联系本站站长，我们会做出相应的bulabula.</div>
</div>

