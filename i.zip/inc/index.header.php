<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="img/tiankonguse.ico" /> 
<title><?php echo $title; ?></title>
<link href="css/main.css" rel="stylesheet">
<link href="css/animation.css" rel="stylesheet">
<link href="css/common.css" rel="stylesheet">
<script src="js/jquery.js"></script>
<script src="js/common.js"></script>

<meta name="description" content="<?php echo $title; ?>">
<meta name="author" content="tiankonguse">


