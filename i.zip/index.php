<?php session_start(); ?>
<!DOCTYPE HTML>
<html lang="zh-cn">
	<head>
		<?php
		$title = "tiankonguse的世界";
		include_once('inc/index.header.php');
		?>
	</head>
	
	<body>
		<header>
			<?php include_once('inc/index.top.php'); ?>
		</header>

		<section>
			<?php include_once("inc/index.body.php") ?>	
		</section>

		<footer>
			<?php  include_once('inc/index.footer.php'); ?>
		</footer>
		
		<?php include_once("inc/index.backTop.php") ?>	

	<div style="clear:both;"></div>
	
	</body>
</html>
<?php include($_SERVER['DOCUMENT_ROOT']."log/zhizhu.php") ?>	
